GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Maternal and reproductive health
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/maternal-and-reproductive-health
	Description: 
	
	
	Date generated: 2025-10-06

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Maternal and reproductive health"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: maternal-and-reproductive-health
	self: maternal-and-reproductive-health
	children: 
		MDG_0000000003	Adolescent birth rate (per 1000 women)
		NUTRITION_ANAEMIA_REPRODUCTIVEAGE_NUM	Anaemia in women of reproductive age (aged 15-49 years) (thousands), by pregnancy status
		NUTRITION_ANAEMIA_REPRODUCTIVEAGE_PREV	Anaemia in women of reproductive age (aged 15-49), prevalence (%), by pregnancy status
		WHS4_154	Antenatal care coverage - at least four visits (%)
		MDG_0000000025	Births attended by skilled health personnel (%)
		WHS4_115	Births by caesarean section (%)
		SRHINSTITUTIONALBIRTH	Births delivered in a health facility (facility/institutional births), proportion (%)
		SDGFP	Family planning, need for family planning satisfied with modern methods, women of reproductive age (aged 15-49 years), proportion (SDG 3.7.1)
		MDG_0000000026	Maternal mortality ratio (per 100 000 live births)
	
